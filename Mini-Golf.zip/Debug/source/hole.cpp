#include "Hole.h"
#include "Entity.h"
#include "Math.h"
#include <SDL.h>

Hole::Hole(Vector2f p_pos, SDL_Texture* p_tex)
:Entity(p_pos, p_tex)
{
}